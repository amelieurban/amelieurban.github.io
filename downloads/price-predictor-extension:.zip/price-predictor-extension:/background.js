// Reserved for future: alarms, scheduled checks, notifications, etc.
